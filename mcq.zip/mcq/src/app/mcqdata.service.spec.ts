import { TestBed } from '@angular/core/testing';

import { McqdataService } from './mcqdata.service';

describe('McqdataService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: McqdataService = TestBed.get(McqdataService);
    expect(service).toBeTruthy();
  });
});
