import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';


@Injectable({
  providedIn: 'root'
})
export class McqdataService {
  public hello = "Welcome to MCQ!";

  //
  constructor( private httpClient:HttpClient) { }

  //
  getAPIData(){
    return this.httpClient.get("assets/data/mcqdata.json");
  }
}
