import { Component, OnInit, AfterViewInit } from '@angular/core';
import { McqdataService } from '../mcqdata.service';

@Component({
  selector: 'app-mcq',
  templateUrl: './mcq.component.html',
  styleUrls: ['./mcq.component.css']
})
export class McqComponent implements OnInit, AfterViewInit {

  //
  public welcome = "";
  private mcqData = {};
  public currentQuestionIndex = 0; 
  private selectedOptionIndex = 0;
  public questionText = "";
  public questionOptions = []; 
  private correctAnswer = 0;
  public selected = "";

  //
  constructor(private elem: ElementRef, private mcqdataService: McqdataService) {  }

  //
  ngOnInit() {
    console.log("mcqdataService: ");
    console.log(this.mcqdataService.hello);
    this.welcome = this.mcqdataService.hello;

    //
    this.getMCQData();

    //
  }

  //
  ngAfterViewInit(){
    let optionsElements = this.elem.nativeElement.querySelectorAll('.classImLookingFor');
  }

  //
  getMCQData(){

    //call for service method getAPIData//
    this.mcqdataService.getAPIData()

    //subscribe to fetch data response//
    .subscribe((data) => {
      this.setMCQData(data);
    });
  }

  //
  setMCQData(_data:{}){
    console.log(_data);

    //
    this.mcqData = _data;

    //
    this.questionText = _data["mcqdata"][this.currentQuestionIndex].question;
    this.questionOptions = _data["mcqdata"][this.currentQuestionIndex].options;
    this.correctAnswer = _data["mcqdata"][this.currentQuestionIndex].answer;
  }

  //
  selectOption(_index:number){
    console.log(_index);

    //
    this.selectedOptionIndex = _index;

    //
    this.selected = "selected";
  }

}
